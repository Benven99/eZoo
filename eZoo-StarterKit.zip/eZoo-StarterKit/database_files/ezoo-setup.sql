-- drop table animals if exists
drop table if exists animals;
drop table if exists feedingschedule;

create table animals (
  animalid integer primary key,
  "name" varchar (100),
  taxKingdom varchar (80),
  taxPhylum varchar (80),
  taxClass varchar (80),
  taxOrder varchar (80),
  taxFamily varchar (80),
  taxGenus varchar (80),
  taxSpecies varchar (80),
  height numeric(6,2),
  weight numeric(6,2),
  "type" varchar (80),
  healthStatus varchar (80),
  feedingScheduleID integer
);

create table feedingschedule (
	schedule_ID integer primary key,
	feedingTime varchar (80),
	recurrence varchar (80),
	food varchar (80),
	notes varchar (100)
);

insert into animals values (
  1,          -- id
  'Leo',      -- name
  'Animalia', -- kingdom
  'Chordata',    -- phylum
  'Mammalia',   -- class
  'Carnivora',-- animal_order
  'Felidae',  -- family
  'Panthera', -- genus
  'P. leo',   -- species
  120.88,     -- height
  400.67,     -- weight
  'Mammal (Terrestrial)',   -- type
  'Healthy',   -- healthStatus
  1
);

insert into feedingschedule values (
	1,
	'Morning',
	'Every Day',
	'Meat',
	'Watch your Hands'
);