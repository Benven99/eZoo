package com.examples.ezoo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.examples.ezoo.model.Animal;
import com.examples.ezoo.model.feeding_schedule;

public class FeedingScheduleDAOImpl implements FeedingScheduleDAO {
	@Override
	public void addFeedingSchedules(feeding_schedule feedingSchedule) throws Exception {
		Connection connection = null;
		PreparedStatement stmt = null;
		int success = 0;

		try {
			connection = DAOUtilities.getConnection();
			String sql = "INSERT INTO feedingschedule VALUES (?, ?, ?, ?, ?)";
			
			stmt = connection.prepareStatement(sql);
			
			stmt.setInt(1, feedingSchedule.getSchedule_ID());
			stmt.setString(2, feedingSchedule.getFeedingTime());
			stmt.setString(3, feedingSchedule.getRecurrence());
			stmt.setString(4, feedingSchedule.getFood());
			stmt.setString(5, feedingSchedule.getNotes());
			
			success = stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if (success == 0) {
			throw new Exception("Save feeding schedule failed: " + feedingSchedule);
		}
	}
	
	@Override
	public void deleteFeedingSchedules(feeding_schedule feedingSchedule) throws Exception {
		Connection connection = null;
		PreparedStatement stmt = null;
		int success = 0;
		
		try {
			connection = DAOUtilities.getConnection();
			String sql = "DELETE FROM feedingschedule WHERE schedule_ID = ?";
			
			stmt = connection.prepareStatement(sql);
			
			stmt.setInt(1, feedingSchedule.getSchedule_ID());
			
			success = stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (connection != null)
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if (success == 0) {
			throw new Exception("Delete feeding schedule failed: " + feedingSchedule);
		}
	}
	
	@Override
	public List<feeding_schedule> getAllFeedingSchedules(){
		List<feeding_schedule> feedingSchedule = new ArrayList<>();
		Connection connection = null;
		Statement stmt = null;
		
		try {
			connection = DAOUtilities.getConnection();
			
			stmt = connection.createStatement();
			
			String sql = "SELECT * FROM feedingschedule";
			
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				feeding_schedule fs = new feeding_schedule();
				
				fs.setSchedule_ID(rs.getInt("schedule_ID"));
				fs.setFeedingTime(rs.getString("feedingTime"));
				fs.setRecurrence(rs.getString("recurrence"));
				fs.setFood(rs.getString("food"));
				fs.setNotes(rs.getString("notes"));
				
				feedingSchedule.add(fs);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return feedingSchedule;
	}
	
	@Override
	public feeding_schedule getFeedingSchedules(Animal animal) {
		feeding_schedule feedingSchedule = new feeding_schedule();
		Connection connection = null;
		PreparedStatement stmt = null;
		
		try {
			connection = DAOUtilities.getConnection();
			
			String sql = "SELECT * FROM feedingschedule WHERE schedule_ID = ?";
			stmt = connection.prepareStatement(sql);
			
			stmt.setLong(1, animal.getfeedingScheduleID());
			
			ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				feedingSchedule.setSchedule_ID(rs.getInt("schedule_ID"));
				feedingSchedule.setFeedingTime(rs.getString("feedingTime"));
				feedingSchedule.setRecurrence(rs.getString("recurrence"));
				feedingSchedule.setFood(rs.getString("food"));
				feedingSchedule.setNotes(rs.getString("notes"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return feedingSchedule;
	}
	
	@Override
	public void assignFeedingSchedule(feeding_schedule feedingSchedule, Animal animal) throws Exception {
		Connection connection = null;
		PreparedStatement stmt = null;
		int success = 0;
		
		try {
			connection = DAOUtilities.getConnection();
			String sql = "UPDATE animals SET schedule_ID = ? WHERE animalid = ?";
			
			stmt = connection.prepareStatement(sql);
			
			stmt.setInt(1, feedingSchedule.getSchedule_ID());
			stmt.setLong(2, animal.getAnimalid());
			
			success = stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if (success == 0) {
			throw new Exception("Assign feeding schedule failed: " + animal);
		}
	}
	
	@Override
	public void removeFeedingSchedule(Animal animals) throws Exception {
		Connection connection = null;
		PreparedStatement stmt = null;
		int success = 0;
		
		try {
			connection = DAOUtilities.getConnection();
			String sql = "UPDATE animals SET feedingScheduleID = null WHERE animalid = ?";
			
			stmt = connection.prepareStatement(sql);
			
			stmt.setLong(1, animals.getAnimalid());
			
			success = stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if (success == 0) {
			throw new Exception("Remove feeding schedule from animal failed: " + animals);
		}
	}
	
	@Override
	public void updateFeedingSchedule(feeding_schedule feedingSchedule) throws Exception {
		Connection connection = null;
		PreparedStatement stmt = null;
		int success = 0;
		
		try {
			connection = DAOUtilities.getConnection();
			String sql = "UPDATE feedingschedule SET feedingTime = ?, recurrence = ?,"
					+ " food = ?, notes = ? WHERE schedule_ID = ?";
			
			stmt = connection.prepareStatement(sql);
			
			
			stmt.setString(1,  feedingSchedule.getFeedingTime());
			stmt.setString(2,  feedingSchedule.getRecurrence());
			stmt.setString(3,  feedingSchedule.getFood());
			stmt.setString(4,  feedingSchedule.getNotes());
			stmt.setInt(5,  feedingSchedule.getSchedule_ID());
			
			success = stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (connection != null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if (success == 0)
			throw new Exception("Update feeding schedule failed: " + feedingSchedule);
	}

}
