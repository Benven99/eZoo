package com.examples.ezoo.dao;

import java.util.List;
import com.examples.ezoo.model.Animal;
import com.examples.ezoo.model.feeding_schedule;

public class FeedingScheduleDAOTest {
	public static void main(String[] args) {
		FeedingScheduleDAO dao = new FeedingScheduleDAOImpl();
		AnimalDAO animalDAO = new AnimalDaoImpl();
		
		feeding_schedule fs1 = new feeding_schedule(400, "1000", "daily", "meat", "watch your fingers");
		feeding_schedule fs2 = new feeding_schedule(401, "1500", "hourly", "potatoe", "check your pockets");
		try {
			dao.addFeedingSchedules(fs1);
			dao.addFeedingSchedules(fs2);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		List<feeding_schedule> allFeedingSchedules = dao.getAllFeedingSchedules();
		for (int i = 0; i < allFeedingSchedules.size(); i++) {
			feeding_schedule f = allFeedingSchedules.get(i);
			System.out.println(f);
		}
		
		List<Animal> animals = animalDAO.getAllAnimals();
		for (Animal a : animals) {
			System.out.println(a.getName() + " has feeding schedule: ");
			System.out.println(dao.getFeedingSchedules(a));
		}
		
		try {
			for (feeding_schedule schedule : allFeedingSchedules) {
				if (schedule.getSchedule_ID() == 1) {
					for (Animal animal : animals) {
						if (animal.getAnimalid() == 4) {
							dao.assignFeedingSchedule(schedule, animal);
						}
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		
		try {
			for (Animal animal : animals) {
				if (animal.getAnimalid() == 1) {
					dao.removeFeedingSchedule(animal);
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		
		try {
			dao.deleteFeedingSchedules(fs1);
			dao.deleteFeedingSchedules(fs2);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		try {
			for (feeding_schedule schedules : allFeedingSchedules) {
				if (schedules.getSchedule_ID() == 1) {
					for (Animal animal : animals) {
						if (animal.getAnimalid() == 1) {
							dao.assignFeedingSchedule(schedules, animal);
						}
					}
				}
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			for (Animal animal : animals) {
				if (animal.getAnimalid() == 4) {
					dao.removeFeedingSchedule(animal);
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
