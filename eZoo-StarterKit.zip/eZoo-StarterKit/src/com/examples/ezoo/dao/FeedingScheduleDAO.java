package com.examples.ezoo.dao;

import java.util.List;

import com.examples.ezoo.model.Animal;
import com.examples.ezoo.model.feeding_schedule;

public interface FeedingScheduleDAO {
	void addFeedingSchedules(feeding_schedule schedule) throws Exception;
	void deleteFeedingSchedules(feeding_schedule schedule) throws Exception;
	List<feeding_schedule> getAllFeedingSchedules();
	feeding_schedule getFeedingSchedules(Animal animal);
	void assignFeedingSchedule(feeding_schedule feedingSchedule, Animal animal) throws Exception;
	void removeFeedingSchedule(Animal animal) throws Exception;
	void updateFeedingSchedule(feeding_schedule schedule) throws Exception;
}
