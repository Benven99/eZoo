package com.examples.ezoo.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.examples.ezoo.dao.DAOUtilities;
import com.examples.ezoo.dao.FeedingScheduleDAO;
import com.examples.ezoo.dao.AnimalDAO;
import com.examples.ezoo.model.feeding_schedule;
import com.examples.ezoo.model.Animal;

@WebServlet("/assignFeedingSchedule")
public class AssignFeedingScheduleServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long animalid = Long.parseLong(request.getParameter("animalid"));
		
		FeedingScheduleDAO dao = DAOUtilities.getFeedingScheduleDAO();
		List<feeding_schedule> feedingSchedule = dao.getAllFeedingSchedules();
		
		AnimalDAO adao = DAOUtilities.getAnimalDao();
		List<Animal> animals = adao.getAllAnimals();
		for (feeding_schedule schedule : feedingSchedule) {
			String animalSchedules = "";
			int count = 0;
			for (Animal animal : animals) {
				if (schedule.getSchedule_ID() == animal.getfeedingScheduleID()) {
					count++;
					String comma = "";
					if (count > 1) {
						comma = ", ";
					}
					animalSchedules += comma + animal.getName() + "[" + animal.getAnimalid() + "]";
				}
			}
			schedule.setAnimals(animalSchedules);
		}
		
		request.getSession().setAttribute("feedingSchedule", feedingSchedule);
		request.getSession().setAttribute("animalid", animalid);
		
		request.getRequestDispatcher("assignFeedingSchedule.jsp").forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int animalid = Integer.parseInt(request.getParameter("animalid"));
		
		AnimalDAO adao = DAOUtilities.getAnimalDao();
		FeedingScheduleDAO fsDAO = DAOUtilities.getFeedingScheduleDAO();
		
		try {
			List<Animal> animals = adao.getAllAnimals();
			Animal animal = new Animal();
			for (Animal a : animals) {
				if (a.getAnimalid() == animalid) {
					animal = a;
				}
			}
			
			if (animal.getfeedingScheduleID() > 0) {
				fsDAO.removeFeedingSchedule(animal);
				request.getSession().setAttribute("message", "Feeding Schedule removed");
			} else {
				int id = Integer.parseInt(request.getParameter("scheedule_ID"));
				String feedTime = request.getParameter("feedingTime");
				String recurrence = request.getParameter("recurrence");
				String food = request.getParameter("food");
				String notes = request.getParameter("notes");
				feeding_schedule fs = new feeding_schedule(
						id,
						feedTime,
						recurrence,
						food,
						notes);
				fsDAO.assignFeedingSchedule(fs, animal);
				
				request.getSession().setAttribute("message", "Feeding Schedule assigned");
			}
			
			request.getSession().setAttribute("messageClass", "alert-success");
			response.sendRedirect("animalCare");
		} catch (Exception e) {
			e.printStackTrace();
			request.getSession().setAttribute("message", "There was a problem assigning/unassigning the feeding schedule");
			request.getSession().setAttribute("messageClass", "alert-danger");
			request.getRequestDispatcher("animalCareHome.jsp").forward(request, response);
		}
	}
}
