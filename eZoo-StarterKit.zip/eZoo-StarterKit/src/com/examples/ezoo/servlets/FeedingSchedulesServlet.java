package com.examples.ezoo.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.examples.ezoo.dao.AnimalDAO;
import com.examples.ezoo.dao.DAOUtilities;
import com.examples.ezoo.dao.FeedingScheduleDAO;
import com.examples.ezoo.model.Animal;
import com.examples.ezoo.model.feeding_schedule;

@WebServlet(description = "This servlet is the main interface into the Feeding Schedules System", urlPatterns = { "/feedingSchedules" })
public class FeedingSchedulesServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		FeedingScheduleDAO dao = DAOUtilities.getFeedingScheduleDAO();
		List<feeding_schedule> feedingSchedule = dao.getAllFeedingSchedules();
		

		AnimalDAO animalDAO = DAOUtilities.getAnimalDao();
		List<Animal> animals = animalDAO.getAllAnimals();
		for (feeding_schedule schedule : feedingSchedule) {
			String animalsWithSchedule = "";
			int count = 0;
			for (Animal animal : animals) {
				if (schedule.getSchedule_ID() == animal.getfeedingScheduleID()) {
					count++;
					String comma = "";
					if (count > 1) {
						comma = ", ";
					}
					animalsWithSchedule += comma + animal.getName() + 
							"[" + animal.getAnimalid() + "]";	
				}
			}
			schedule.setAnimals(animalsWithSchedule);
		}

		request.getSession().setAttribute("feedingSchedule", feedingSchedule);
				
		request.getRequestDispatcher("feedingSchedules.jsp").forward(request, response);
	}
}
