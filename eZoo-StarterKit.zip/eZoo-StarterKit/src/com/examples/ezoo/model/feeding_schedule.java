package com.examples.ezoo.model;

public class feeding_schedule {
	private int schedule_ID = 0;
	private String feedingTime = "";
	private String recurrence = "";
	private String food = "";
	private String notes = "";
	private String animals = "";
	
	public feeding_schedule() {}
	
	public feeding_schedule(int schedule_ID, String feedingTime, String recurrence, String food, String notes) {
		super();
		this.schedule_ID = schedule_ID;
		this.feedingTime = feedingTime;
		this.recurrence = recurrence;
		this.food = food;
		this.notes = notes;
	}
	
	public int getSchedule_ID() {
		return schedule_ID;
	}

	public void setSchedule_ID(int schedule_ID) {
		this.schedule_ID = schedule_ID;
	}

	public String getFeedingTime() {
		return feedingTime;
	}

	public void setFeedingTime(String feedingTime) {
		this.feedingTime = feedingTime;
	}

	public String getRecurrence() {
		return recurrence;
	}

	public void setRecurrence(String recurrence) {
		this.recurrence = recurrence;
	}

	public String getFood() {
		return food;
	}

	public void setFood(String food) {
		this.food = food;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}
		
	public String getAnimals() {
		return animals;
	}

	public void setAnimals(String animals) {
		this.animals = animals;
	}

	@Override
	public String toString() {
		if (this.schedule_ID != 0)
			return "feeding_schedule [" + "schedule_ID = " + schedule_ID + ", feedingTime= " + feedingTime + ", recurrence= " + recurrence + ", food= "
				+ food + ", notes= " + notes + "]";
		else
			return "No Feeding Schedule";
	}
}
